## Web IMSDK的微信小程序接入
##### 1.设置微信公众后台，添加request合法域名

http://webim.tim.qq.com

https://tls.qcloud.com

![image](http://im-1251132611.costj.myqcloud.com/wxsetting.png)



##### 2.下载最新版的sdk包

​	https://www.qcloud.com/product/im


![image](http://im-1251132611.costj.myqcloud.com/wxapp.png)





##### 3.使用小程序工具进行开发

​	![image](http://im-1251132611.costj.myqcloud.com/code.png)



其他回调方式方法请参考小程序的规范以及demo代码